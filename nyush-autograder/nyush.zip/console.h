#ifndef _CONSOLE_H_
#define _CONSOLE_H_

void manipulate_args(int argc, char ** argv, int toBreak, pid_t* currentProcess);
int shell();

#endif
